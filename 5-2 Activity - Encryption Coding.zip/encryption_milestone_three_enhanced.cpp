// Encryption.cpp
// XOR encryption/decryption with file input and output

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <ctime>

using namespace std;

/// Reads the entire contents of a file into a string.
string read_file(const string& filename)
{
    ifstream input_file(filename, ios::binary);

    if (!input_file)
    {
        throw runtime_error("Unable to open input file: " + filename);
    }

    ostringstream buffer;
    buffer << input_file.rdbuf();
    return buffer.str();
}

/// Extracts the student name from the first line of the input text.
string get_student_name(const string& text)
{
    size_t newline_pos = text.find('\n');

    if (newline_pos == string::npos)
    {
        return text;
    }

    return text.substr(0, newline_pos);
}

/// Performs XOR encryption/decryption using a repeating key.
/// XOR is symmetric, so the same function works for both operations.
string encrypt_decrypt(const string& source, const string& key)
{
    if (source.empty())
    {
        throw invalid_argument("Source text cannot be empty.");
    }

    if (key.empty())
    {
        throw invalid_argument("Key cannot be empty.");
    }

    string output = source;
    const size_t source_length = source.length();
    const size_t key_length = key.length();

    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    return output;
}

/// Converts binary-style encrypted data into hexadecimal text
/// so it can be safely written to a file and reviewed.
string to_hex(const string& data)
{
    ostringstream hex_stream;
    hex_stream << hex << setfill('0');

    for (unsigned char ch : data)
    {
        hex_stream << setw(2) << static_cast<int>(ch);
    }

    return hex_stream.str();
}

/// Returns the current date/time as a formatted string.
string get_timestamp()
{
    time_t now = time(nullptr);
    tm local_time{};

#ifdef _WIN32
    localtime_s(&local_time, &now);
#else
    local_time = *localtime(&now);
#endif

    ostringstream time_stream;
    time_stream << put_time(&local_time, "%Y-%m-%d %H:%M:%S");
    return time_stream.str();
}

/// Saves processed output to a file.
void save_data_file(const string& filename,
                    const string& student_name,
                    const string& operation,
                    const string& key,
                    const string& data,
                    bool save_as_hex = false)
{
    ofstream output_file(filename, ios::out | ios::binary);

    if (!output_file)
    {
        throw runtime_error("Unable to open output file: " + filename);
    }

    output_file << "Student Name: " << student_name << '\n';
    output_file << "Timestamp: " << get_timestamp() << '\n';
    output_file << "Operation: " << operation << '\n';
    output_file << "Key Length: " << key.length() << '\n';

    if (save_as_hex)
    {
        output_file << "Data Format: Hexadecimal\n";
        output_file << "Data:\n" << to_hex(data) << '\n';
    }
    else
    {
        output_file << "Data Format: Plain Text\n";
        output_file << "Data:\n" << data << '\n';
    }
}

int main()
{
    try
    {
        cout << "Encryption / Decryption Test" << endl;

        const string input_filename = "inputdatafile.txt";
        const string encrypted_filename = "encrypteddatafile.txt";
        const string decrypted_filename = "decrypteddatafile.txt";
        const string key = "password";

        const string source_text = read_file(input_filename);
        const string student_name = get_student_name(source_text);

        const string encrypted_text = encrypt_decrypt(source_text, key);
        save_data_file(encrypted_filename, student_name, "Encryption", key, encrypted_text, true);

        const string decrypted_text = encrypt_decrypt(encrypted_text, key);
        save_data_file(decrypted_filename, student_name, "Decryption", key, decrypted_text, false);

        cout << "Input File: " << input_filename << '\n';
        cout << "Encrypted Output: " << encrypted_filename << '\n';
        cout << "Decrypted Output: " << decrypted_filename << '\n';
        cout << "Process completed successfully." << endl;
    }
    catch (const exception& e)
    {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
